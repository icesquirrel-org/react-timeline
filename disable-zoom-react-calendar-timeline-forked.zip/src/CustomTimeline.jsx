import React, { Component } from "react";
import moment from "moment";

import Timeline from "react-calendar-timeline";

import generateFakeData from "./generate-fake-data";

var keys = {
  groupIdKey: "id",
  groupTitleKey: "title",
  groupRightTitleKey: "rightTitle",
  itemIdKey: "id",
  itemTitleKey: "title",
  itemDivTitleKey: "title",
  itemGroupKey: "group",
  itemTimeStartKey: "start",
  itemTimeEndKey: "end",
  groupLabelKey: "title"
};
var timeStep = {
  second: 0,
  minute: 0,
  hour: 0,
  day: 0,
  month: 1,
  year: 1
};
export default class App extends Component {
  constructor(props) {
    super(props);
    const data = generateFakeData();
    const { groups, items } = data;
    const defaultTimeStart = moment().startOf("day").toDate();
    const defaultTimeEnd = moment().startOf("day").add(360, "day").toDate();

    this.state = {
      groups,
      items,
      defaultTimeStart,
      defaultTimeEnd
    };
  } 
  render() {
    const { groups, items, defaultTimeStart, defaultTimeEnd } = this.state;

    items.sort(function compare(a, b) {
      if (a.start > b.start) return 1;
      if (a.start < b.start) return -1;
      return 0;
    });
     
    const canvasTimeStart = items[0].start;
    
    items.sort(function compare(a, b) {
      if (a.end > b.end) return 1;
      if (a.end < b.end) return -1;
      return 0;
    });
    const canvasTimeEnd = items[items.length - 1].end;
    
    const defaultTimeRange = canvasTimeEnd - canvasTimeStart;
    
    
    
    return (
      <Timeline
        groups={groups}
        items={items}
        keys={keys}
        defaultTimeStart={canvasTimeStart}
        defaultTimeEnd={canvasTimeEnd}
        timeSteps={timeStep}
       
        canvasTimeStart={canvasTimeStart}
        canvasTimeEnd={canvasTimeEnd}
        visibleTimeStart={canvasTimeStart}
        visibleTimeEnd={canvasTimeEnd}
      />
    );
  }
}
